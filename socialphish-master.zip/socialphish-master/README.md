# SocialPhish v1.6+

The most complete Phishing Tool, with 32 templates +1 customizable

## Legal disclaimer:
Usage of SocialPhish for attacking targets without prior mutual consent is illegal. It's the end user's responsibility to obey all applicable local, state and federal laws. Developers assume no liability and are not responsible for any misuse or damage caused by this program 


##### Usage:
```
git clone https://github.com/pvanfas/socialphish.git
cd SocialPhish
chmod +x socialphish.sh
./socialphish.sh
```
