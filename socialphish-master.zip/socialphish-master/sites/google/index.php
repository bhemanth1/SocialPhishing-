<?php
include 'ip.php';
header('Location: start.php');
exit
?>
